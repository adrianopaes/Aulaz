/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula_2;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Adriano
 */
public class Aulaex{ 
        public static void main (String[] args){
            JFrame janela = new JFrame ("Projeto Disciplina");
            JPanel painel = new JPanel();
            janela.setSize(300,200);
            janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            janela.setVisible(true);
            janela.add(painel);
            JLabel rotulo = new JLabel();
            rotulo.setText("Nome");
            painel.add(rotulo);
            String number = JOptionPane.showInputDialog("Digite um número");
            JOptionPane.showMessageDialog(null, "O número digitado foi " + number , "ifro" ,  JOptionPane.PLAIN_MESSAGE);
            
        }



    
}
